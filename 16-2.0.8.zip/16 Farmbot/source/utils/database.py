import requests
import sqlite3
import os as fs
import time
import config as config
import utils.colors as colors
import pysqlsimplecipher.decryptor as decryptor
# from pysqlcipher3 import dbapi2 as sqlite


def download(ver, os, token, secret, version, url):
    print(colors.render('{message}[!] downloading database... (this may take awhile.)'))
    timer_start = int(round(time.time(), 0))
    # store = outgame.getDatabase(ver, os, token, secret)
    # url = store['url']
    r = requests.get(url, stream=True, allow_redirects=True)
    f = open('./data/enc_' + ver + '.db', 'wb')
    for chunk in r.iter_content(1024):
        f.write(chunk)
    f.close()
    timer_finish = int(round(time.time(), 0))
    timer_total = timer_finish - timer_start
    print(str(timer_total) + ' second(s) download.')
    if ver == 'gb':
        x0a1_1 = config.x0a1_0[0].encode()
    else:
        x0a1_1 = config.x0a1_0[1].encode()
    print(colors.render('{message}[!] decrypting database... (this may take awhile.)'))
    timer_start = int(round(time.time(), 0))
    decryptor.decrypt_file('./data/enc_' + ver + '.db', bytearray(x0a1_1), './data/' + ver + '.db')
    fs.unlink('./data/enc_' + ver + '.db')
    f = open('./data/' + ver + '-data.txt', 'w')
    f.write(str(version) + '\n')
    f.close()
    timer_finish = int(round(time.time(), 0))
    timer_total = timer_finish - timer_start
    print(str(timer_total) + ' second(s) decrypt.')


def create_connection(file, ver):
    conn = sqlite3.connect(file, isolation_level=None)
    c = conn.cursor()
    return [conn, c]


def db_query(file, pw, query, table, where, amount):
    connection = create_connection(file, pw)
    con, cur = connection[0], connection[1]
    if query is None:
        if where:
            query = "SELECT * FROM " + table + " WHERE " + str(where)
        else:
            query = "SELECT * FROM " + table
    cur.execute(query)
    if amount == 0:
        results = cur.fetchone()
    else:
        results = cur.fetchall()
    cur.close()
    con.close()
    return results


def exec_query(file, pw, query, table, where, amount):
    if file == './data/gb.db':
        if fs.path.isfile(file):
            result = db_query(file, pw, query, table, where, amount)
            if result is not None and len(result) != 0:
                return result
            else:
                if fs.path.isfile('./data/jp.db'):
                    return db_query('./data/jp.db', pw, query, table, where, amount)
        else:
            return db_query('./data/jp.db', pw, query, table, where, amount)
    else:
        return db_query(file, pw, query, table, where, amount)


def exec_change(file, pw, query, values=None):
    connection = create_connection(file, pw)
    con, cur = connection[0], connection[1]
    try:
        if values is not None:
            cur.execute(query, values)
        else:
            cur.execute(query)
        con.commit()
        if 'SELECT' in query or 'select' in query:
            results = cur.fetchone()
        else:
            results = ()
        cur.close()
        return results
    finally:
        con.close()
