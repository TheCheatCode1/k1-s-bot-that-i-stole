max_mass_rerolls = 10
gb_url = 'https://ishin-global.aktsk.com'
gb_port = None
jp_url = 'https://ishin-production.aktsk.jp'
jp_port = None
gb_maint = False
jp_maint = False
gb_code = {
    'android': None,
    'ios': None
}
jp_code = {
    'android': None,
    'ios': None
}
x0a1_0 = []
x0a2_0 = []
x0a4_0 = ['1002630', '1002640', '1002650', '1005480', '1011480', '1011481', '1013400', '1003970', '1009850', '1012230', '1012240', '1012250', '1012260', '1012270', '1018550', '1015860']
