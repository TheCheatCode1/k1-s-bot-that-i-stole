import time
import os
import json
from . import ingame
'''import utils.funcs as funcs
import utils.error as error
import utils.database as database'''
from utils import funcs
from utils import error
from utils import database

# account defaults
'''lang = {'gb': 'en','jp': 'jp'}
country = {'gb': 'US', 'jp': 'JP'}
currency = {'gb': 'USD', 'jp': 'JPY'}'''
lang = 'en'
country = 'US'
currency = 'USD'
uuid = '0f97df48-01e3-4d8f-8ba0-a1e8cced278c:5bf18553fe25d277'
ad = '95c27e08-72bb-4760-83e8-9e878d1999f8'

# android User-Agent
device_name1 = 'SM'
device_model1 = 'SM-S10'
device_ver1 = '9.0'
device_agent1 = 'Dalvik/2.1.0 (Linux; Android 9.0; SM-S10)'
# ios User-Agent
device_name2 = 'iPhone'
device_model2 = 'iPhone XR'
device_ver2 = '13.0'
device_agent2 = 'CFNetwork/808.3 Darwin/16.3.0 (iPhone; CPU iPhone OS 13_0 like Mac OS X)'

# cached account config
loaded = None  # save file
account = ''  # identifier
acc_os = ''  # platform
acc_ver = ''  # game version
sess_token = ''  # session token
sess_secret = ''  # session secret

# client data
database_ts = str(int(round(time.time(), 0)))
asset_ts = None

file_ts1 = str(int(round(time.time(), 0)))
file_ts2 = str(int(round(time.time(), 0)))
db_ts1 = str(int(round(time.time(), 0)))
db_ts2 = str(int(round(time.time(), 0)))

# store account information
teams = {}
support_leader = 0
cards = []
item_cards = []
events = {}


def assign_tables():
    global loaded
    global cards
    global item_cards
    # exec_query(file, pw, query, table, where, amount)
    # database.exec_query(f"./data/gb.db", None, None,
    # database.exec_query(f"./boxes/{loaded}.db", None, None
    cards = database.exec_query(f"./boxes/{loaded}.db", None, None, 'cards', None, 1)
    item_cards = database.exec_query(f"./boxes/{loaded}.db", None, None, 'item_cards', None, 1)
    return True


def card_pool(card):
    global loaded
    query = database.exec_query(f"./boxes/{loaded}.db", None, None, 'drops', 'unique_id=' + str(card), 0)
    if query is None:
        database.exec_change(f"./boxes/{loaded}.db", None, f"INSERT INTO drops(unique_id, test) VALUES (?, ?)", (int(card), 0))


def remove_cards(input_cards, input_items):
    global loaded
    if input_cards is None:
        input_cards = []
    if input_items is None:
        input_items = []
    card_id = None
    for i in input_cards:
        if 'id' in i and i['id'] is not None:
            card_id = i['id']
        elif i is int:
            card_id = i
        query = database.exec_query(f"./boxes/{loaded}.db", None, None, 'cards', 'id=' + str(card_id), 0)
        if query is not None:
            database.exec_change(f"./boxes/{loaded}.db", None, "DELETE FROM cards WHERE id=?", (int(card_id),))
        query = database.exec_query(f"./boxes/{loaded}.db", None, None, 'drops', 'unique_id=' + str(card_id), 0)
        if query is not None:
            database.exec_change(f"./boxes/{loaded}.db", None, "DELETE FROM drops WHERE unique_id=?",
                                 (int(card_id),))
    for i in input_items:
        if 'card_id' in i and i['card_id'] is not None:
            query = database.exec_query(f"./boxes/{loaded}.db", None, None, 'item_cards', 'card_id=' + str(i['card_id']), 0)
            if query is not None:
                if i['quantity'] != 0:
                    database.exec_change(f"./boxes/{loaded}.db", None, "UPDATE item_cards SET quantity=? WHERE card_id=?", (int(query[1]) + int(i['quantity']), int(i['card_id'])))
                else:
                    database.exec_change(f"./boxes/{loaded}.db", None, "DELETE FROM item_cards WHERE card_id=?", (int(i['card_id']),))
    assign_tables()


def add_cards(input_cards, input_items):
    global loaded
    if input_cards is None:
        input_cards = []
    if input_items is None:
        input_items = []
    for i in input_cards:
        query = database.exec_query(f"./boxes/{loaded}.db", None, None, 'cards', 'id=' + str(i['id']), 0)
        if query is None:
            database.exec_change(f"./boxes/{loaded}.db", None, f"INSERT INTO cards(id, card_id, updated_at, serialized) VALUES (?, ?, ?, ?)", (int(i['id']), int(i['card_id']), int(i['updated_at']), str(json.dumps(i))))
    for i in input_items:
        query = database.exec_query(f"./boxes/{loaded}.db", None, None, 'item_cards', 'card_id=' + str(i['card_id']), 0)
        if query is None:
            if int(i['quantity']) != 0:
                database.exec_change(f"./boxes/{loaded}.db", None, f"INSERT INTO item_cards(card_id, quantity) VALUES (?, ?)", (int(i['card_id']), int(i['quantity'])))
        else:
            update_cards(None, input_items)
    assign_tables()


def update_cards(input_cards, input_items, eza_drops=None):
    #print(input_items)
    global loaded
    if input_cards is None:
        input_cards = []
    if input_items is None:
        input_items = []
    for i in input_cards:
        query = database.exec_query(f"./boxes/{loaded}.db", None, None, 'cards', 'id=' + str(i['id']), 0)
        if query is not None:
            database.exec_change(f"./boxes/{loaded}.db", None, "UPDATE cards SET updated_at=?, serialized=? where id=?",
                          (int(i['updated_at']), str(json.dumps(i)), int(i['id'])))
    for i in input_items:
        query = database.exec_query(f"./boxes/{loaded}.db", None, None, 'item_cards', 'card_id=' + str(i['card_id']), 0)
        if query is not None:
            if int(i['quantity']) != 0:
                if eza_drops:
                    database.exec_change(f"./boxes/{loaded}.db", None, "UPDATE item_cards SET quantity=? where card_id=?", (int(i['quantity']), int(i['card_id'])))
                else:
                    database.exec_change(f"./boxes/{loaded}.db", None, "UPDATE item_cards SET quantity=? where card_id=?", (int(query[1]) + int(i['quantity']), int(i['card_id'])))
            else:
                remove_cards(None, input_items)
    assign_tables()


def load_account(save, iden, par_ver, par_os, token, secret, show=False):
    global loaded
    global account
    global acc_ver
    global acc_os
    global sess_token
    global sess_secret
    global teams
    global support_leader
    global events
    loaded, account, acc_ver, acc_os, sess_token, sess_secret = save, iden, par_ver, par_os, token, secret
    db_exists = False
    if not os.path.isfile(f"./boxes/{loaded}.db"):
        open(f"./boxes/{loaded}.db", 'w')
        database.exec_change(f"./boxes/{loaded}.db", None, "CREATE TABLE cards(id INTEGER PRIMARY KEY, card_id INTEGER, updated_at INTEGER, serialized TEXT NOT NULL)")
        database.exec_change(f"./boxes/{loaded}.db", None, "CREATE TABLE item_cards(card_id INTEGER PRIMARY KEY, quantity INTEGER)")
        database.exec_change(f"./boxes/{loaded}.db", None, "CREATE TABLE drops(unique_id INTEGER PRIMARY KEY, test INTEGER)")
    else:
        db_exists = True
    if funcs.check_database(acc_ver, acc_os, sess_token, sess_secret):
        funcs.check_asset()
        if not db_exists:
            store = ingame.login_resources(acc_ver, acc_os, sess_token, sess_secret, None)
        else:
            store = ingame.login_resources(acc_ver, acc_os, sess_token, sess_secret, str(int(round(time.time(), 0))))
        if 'error' not in store:
            if 'teams' in store:
                teams = store['teams']
            if 'support_leaders' in store:
                if 'support_leader_ids' in store['support_leaders']:
                    if len(store['support_leaders']['support_leader_ids']) != 0:
                        support_leader = store['support_leaders']['support_leader_ids'][0]
            if 'cards' in store:
                if not db_exists:
                    add_cards(store['cards'], None)
            if 'item_cards' in store:
                if not db_exists:
                    add_cards(None, store['item_cards'])
            assign_tables()
        else:
            error.handler('resrc1', store)
        store = ingame.events(acc_ver, acc_os, sess_token, sess_secret)
        if 'error' not in store:
            events = store
        else:
            error.handler('errLS', store)
        if show:
            funcs.navigator(99)
    else:
        loaded = None


def update_events():
    global acc_ver
    global acc_os
    global sess_token
    global sess_secret
    global events
    store = ingame.events(acc_ver, acc_os, sess_token, sess_secret)
    if 'error' not in store:
        events = store
    else:
        error.handler('errorLS', store)
